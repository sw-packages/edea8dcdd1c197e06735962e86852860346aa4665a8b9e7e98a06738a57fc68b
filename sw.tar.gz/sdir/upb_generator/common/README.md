This directory contains APIs that are used by multiple code generators, but not
public to users.
